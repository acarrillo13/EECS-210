"""
Alexander Carrillo
EECS 210 Assignment 6 part 3
created 4/2/2024
last edit: 4/2/2024
All code is written by Alexander Carrillo

Inputs:
a)
userin1 = 414
userin2 = 662

b)
userin1 = 6
userin2 = 14

c)
userin1 = 24
userin2 = 36

d)
userin1 = 12
userin2 = 42

e)
userin1 = 252
userin2 = 198

Outputs:
a)
First number: 414
Second number: 662
q1 = 0
q2 = 1
q3 = 1
q4 = 1
q5 = 2
q6 = 41

s0 = 1
t0 = 0
s1 = 0
t1 = 1
s2 = 1 - (0 * 0) = 1
t2 = 0 - (1 * 0) = 0
s3 = 0 - (1 * 1) = -1
t3 = 1 - (0 * 1) = 1
s4 = 1 - (-1 * 1) = 2
t4 = 0 - (1 * 1) = -1
s5 = -1 - (2 * 1) = -3
t5 = 1 - (-1 * 1) = 2
s6 = 2 - (-3 * 2) = 8
t6 = -1 - (2 * 2) = -5

2 = 8 * 414 + -5 * 662

b)
First number: 6
Second number: 14
q1 = 0
q2 = 2
q3 = 3

s0 = 1
t0 = 0
s1 = 0
t1 = 1
s2 = 1 - (0 * 0) = 1
t2 = 0 - (1 * 0) = 0
s3 = 0 - (1 * 2) = -2
t3 = 1 - (0 * 2) = 1

2 = -2 * 6 + 1 * 14

c)
First number: 24
Second number: 36
q1 = 0
q2 = 1
q3 = 2

s0 = 1
t0 = 0
s1 = 0
t1 = 1
s2 = 1 - (0 * 0) = 1
t2 = 0 - (1 * 0) = 0
s3 = 0 - (1 * 1) = -1
t3 = 1 - (0 * 1) = 1

12 = -1 * 24 + 1 * 36

d)
First number: 12
Second number: 42
q1 = 0
q2 = 3
q3 = 2

s0 = 1
t0 = 0
s1 = 0
t1 = 1
s2 = 1 - (0 * 0) = 1
t2 = 0 - (1 * 0) = 0
s3 = 0 - (1 * 3) = -3
t3 = 1 - (0 * 3) = 1

6 = -3 * 12 + 1 * 42

e)
First number: 252
Second number: 198
q1 = 1
q2 = 3
q3 = 1
q4 = 2

s0 = 1
t0 = 0
s1 = 0
t1 = 1
s2 = 1 - (0 * 1) = 1
t2 = 0 - (1 * 1) = -1
s3 = 0 - (1 * 3) = -3
t3 = 1 - (-1 * 3) = 4
s4 = 1 - (-3 * 1) = 4
t4 = -1 - (4 * 1) = -5

18 = 4 * 252 + -5 * 198
"""

def gcd(a,b):#finds greatest common denominator
    q = 0 #inital q, tracks the number
    qlist = [] #all q's will be added to this
    while True:#runs code until remainder is 0
        q += 1#adds one to the q count
        remainder=a%b#gets remainder of a mod b
        print(f'q{q} = {a//b}')#prints the process
        qlist.append(a//b)#adds a q to the qlist
        if remainder == 0:#exit returns b which is our gcd
            gcd = b #sets gcd
            break
        #varilbe shifts
        a = b
        b = remainder
    #inital s and t values, future s and t's will be added to these lists
    slist = [1,0]
    tlist = [0,1]
    #prints initial s and t values
    print(f'\ns0 = 1')
    print(f't0 = 0')
    print(f's1 = 0')
    print(f't1 = 1')
    iteration = 0 #tracks what iteration the loop is on too adjust the index of s, t, and q lists
    qlist = qlist[:-1]#removes the last value of qlist to have the equation end when it's supposed to
    for i in qlist:#loop goes through q list
        s = slist[0+iteration] - (slist[1+iteration] * qlist[0+iteration])#sets s to the value of that s iteration
        print(f's{iteration+2} = {slist[0+iteration]} - ({slist[1+iteration]} * {qlist[0+iteration]}) = {slist[0+iteration] - (slist[1+iteration] * qlist[0+iteration])}')#prints the s iteration, the equation, and what the equation equals
        slist.append(s)#adds the s to the slist
        t = tlist[0+iteration] - (tlist[1+iteration] * qlist[0+iteration])#sets t to the value of that t iteration
        print(f't{iteration+2} = {tlist[0+iteration]} - ({tlist[1+iteration]} * {qlist[0+iteration]}) = {tlist[0+iteration] - (tlist[1+iteration] * qlist[0+iteration])}')#prints the t iteration, the equation, and what the equation equals
        tlist.append(t)#adds the t to the tlist
        iteration += 1#increases the iteration
    return s, t, gcd#retruns the final s, t, and gcd values
print('e)')#problem number a-e
a = int(input("First number: "))#userinput for all of the samples,a 
b = int(input("Second number: "))#userin for b
s,t,gcd = gcd(a,b)#sets varibles for the values returned from our gcd function
print(f'\n{gcd} = {s} * {a} + {t} * {b}')#filnal print: gcd = s * a + t * b

