"""
Alexander Carrillo
EECS 210 Assignment 6 part 2
created 3/27/2024
last edit: 4/2/2024
All code is written by Alexander Carrillo
Inputs:
a)
userin1 = 414
userin2 = 662

b)
userin1 = 6
userin2 = 14

c)
userin1 = 24
userin2 = 36

d)
userin1 = 12
userin2 = 42

e)
userin1 = 252
userin2 = 198

Outputs:
a)
First number: 414
Second number: 662
662 = 1 * 414 + 248
414 = 1 * 248 + 166
248 = 1 * 166 + 82
166 = 2 * 82 + 2
2 = 1 * 166 - 2 * 82
2 = 1 * 166 - 2 * (248 - 1 * 166)
2 = 3 * 166 - 2 * 248
2 = 3 * (414 - 1 * 248) - 2 * 248
2 = 3 * 414 - 5 * 248
2 = 3 * 414 - 5 * (662 - 1 * 414)
2 = 8 * 414 - 5 * 662
GCD is: 2

b)
b)
First number: 6
Second number: 14
14 = 2 * 6 + 2
2 = 1 * 14 - 2 * 6
GCD is: 2

c)
First number: 24
Second number: 36
36 = 1 * 24 + 12
12 = 1 * 36 - 1 * 24
GCD is: 12

d)
First number: 12
Second number: 42
42 = 3 * 12 + 6
6 = 1 * 42 - 3 * 12
GCD is: 6

e)
First number: 252
Second number: 198
252 = 1 * 198 + 54
198 = 3 * 54 + 36
54 = 1 * 36 + 18
18 = 1 * 54 - 1 * 36
18 = 1 * 54 - 1 * (198 - 3 * 54)
18 = 4 * 54 - 1 * 198
18 = 4 * (252 - 1 * 198) - 1 * 198
18 = 4 * 252 - 5 * 198
GCD is: 18
"""

def bezgcd(a,b):#finds greatest common denominator
    saved = []#saves the values of the varibles for second step
    while True:#runs code until remainder is 0
        remainder=a%b#gets remainder of a mod b
        if remainder == 0:#exit returns b which is our gcd
            break
        c = a//b#floor divides a and b for our equations
        print(f'{a} = {c} * {b} + {remainder}')#prints the process
        saved.append([a,b,c,remainder])
        #rearranges the varibles for the next iteration
        a = b
        b = remainder
        d = 1#d is for the second setp
    remainder = saved[-1][0] #sets up the remainder for the second step
    print(f'{b} = {d} * {remainder} - {c} * {a}')
    for i in saved[::-1]:#goes back wards through saved
        #print(f'{i[-1]} {remainder} {a}')
        if i[-1] == a:#if the second value is equal to the remainder it replaces it with the equation using varibles from saved
            print(f'{b} = {d} * {remainder} - {c} * ({i[0]} - {i[2]} * {i[1]})')
            #changes a and d for next iteration
            a = i[0]
            d = d+c*i[2]
            ###c = c *i[2]
            print(f'{b} = {d} * {remainder} - {c} * {a}')
        elif i[-1] == remainder:#if the first value is equal to the remainder it replaces it with the equation using varibles from saved
            print(f'{b} = {d} * ({i[0]} - {i[2]} * {i[1]}) - {c} * {a}')
            #changes c and remainder for next iteration
            remainder = i[0]
            c = d * i[2] + c
            d = d * i[2]
            print(f'{b} = {d} * {remainder} - {c} * {a}')
    return b#returns gcd

print('e)')#problem number a-e
userin1 = int(input("First number: "))#userinput for all of the samples, a
userin2 = int(input("Second number: "))#userin for b
#sets inputs to varibles
a = userin1 
b = userin2
if userin2 > userin1:#reorders the varibles so greatest is compared first
    a = userin2
    b = userin1
print(f'GCD is: {bezgcd(a,b)}')#prints the gcd of a and b
