"""
Alexander Carrillo
EECS 210 Assignment 6 part 1
created 3/22/2024
last edit: 3/22/2024
All code is written by Alexander Carrillo

inputs:
a.
a = 414
b = 662

b.
a =6
b = 14

c.
a = 24
b = 36

d.
a = 12
b = 42

e.
a =252
b =198

Outputs:
a)
First number: 414
Second number: 662
414/662=0R414
662/414=1R248
414/248=1R166
248/166=1R82
166/82=2R2
GCD is: 2

b)
First number: 6
Second number: 14
6/14=0R6
14/6=2R2
GCD is: 2

c)
First number: 24
Second number: 36
24/36=0R24
36/24=1R12
GCD is: 12

d)
First number: 12
Second number: 42
12/42=0R12
42/12=3R6
GCD is: 6

e)
First number: 252
Second number: 198
252/198=1R54
198/54=3R36
54/36=1R18
GCD is: 18
"""

def gcd(a,b):#finds greatest common denominator 
    while True:#runs code until remainder is 0
        remainder=a%b#gets remainder of a mod b
        print(f'{a}/{b}={a//b}R{remainder}')#prints the process
        if remainder == 0:#exit returns b which is our gcd
            return b #returns the gcd
        #change the varibles
        a = b
        b = remainder
print('e)')#problem number a-e
a = int(input("First number: "))#userinput for all of the samples, a
b = int(input("Second number: "))#userin for b
print(f'GCD is: {gcd(a,b)}')#prints the gcd of a and b
